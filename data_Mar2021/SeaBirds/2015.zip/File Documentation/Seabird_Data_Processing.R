#########################################################################################################################################
# Script Author: Daniel Cushing                                                                                                         #
# Date Created: Feburary 10 2016                                                                                                        #
# Date Modified: February 17 2016                                                                                                       #
#                                                                                                                                       #
# Version information: Script written using R version 3.2.3                                                                             #
# Package information: Script requires that R package "sp" is installed (used sp version 1.2-2).                                        #
#                                                                                                                                       #
# Purpose: 1) Subdivide seabird survey data into contiguous 3-km transect subsections.                                                  #
# Purpose: 2) Calculate observed densities of seabird taxa and summary information for each transect subsection.                        #
#                                                                                                                                       #
# Input: Dlog data file in .csv format.                                                                                                 #
#                                                                                                                                       #
# Output: 1) Dlog data file is modified by a. calculating bins and b. adding transect subsection information to "Comment3" field.       #
# Output: 2) New output file is created, containing density and summary information for each transect subsection.                       #
#                                                                                                                                       #
# Note 1: Script requires that all transect starts/stops and pauses/resumes are noted in the field "Comment1",                          #
# using the specific comments "START TRAN", "END TRAN", "PAUSE TRAN", and "RESUME TRAN".                                                #
# Note 2: Lat/Lon fields must not contain errors or NA values. If needed, complete any error correction before running this script.     #
# Note 3: Warning - "Bin" and "Comment3" columns are assumed to be empty and contents will be over-written in the processed dlog file.  #
#########################################################################################################################################


### SECTION 1: LOAD DATA, PROVIDE USER INPUTS
## Set the working directory
# Edit this path as required
setwd("/Users/Dan/Projects/AMBON/Data/Original_Data/AMBON_Survey_Data/Seabird_Data_Processing/3_Transect_Sections")

## Read in dlog .csv data file
# Edit this file name as required
DAT = read.table("AMBON_2015_SeabirdData.csv", header=TRUE, sep=",", comment.char="", 
    colClasses=c("numeric" , "numeric" , "numeric" , "numeric" , "numeric" , "numeric",
        "numeric" , "numeric" , "numeric" , "numeric" , "factor" , "factor" , "numeric",
        "numeric" , "factor" , "factor" , "character" , "character" , "factor" , "numeric",
        "factor" , "factor" , "factor" , "numeric" , "factor" , "factor" , "factor" , "factor" ,
        "factor" , "factor" , "numeric" , "factor" , "factor" , "factor" , "numeric"))

# Specify the taxa for which density will be estimated, in desired order
# This list includes all seabird taxa recorded on- or off-transect during the 2015 AMBON cruise. 
# Excludes unidentified bird spp. (UNBI), landbirds (PASS) and intertidal-associated shorebirds (LBDO, UNSB).
# Also excludes mammals, boats, debris.
# Edit list as needed. 
TAXA = c(
    "RTLO" , "PALO" , "YBLO" , "UNLO" , "NOFU" , "STSH" , "UNDS" , "LTDU" , "COEI" , "KIEI" , "SPEI" , "UNEI" , 
    "RBME" , "UNDU" , "UNWF" , "REPH" , "RNPH" , "UNPH" , "POJA" , "PAJA" , "LTJA" , "UNJA" , "GLGU" , "HEGU" , 
    "THGU" , "BLKI" , "SAGU" , "UNGU" , "ARTE" , "COMU" , "TBMU" , "UNMU" , "DOVE" , "BLGU" , "UNGI" , "KIMU" , 
    "BRMU" , "ANMU" , "PAAU" , "CRAU" , "LEAU" , "UNAU" , "USDA" , "HOPU" , "TUPU" , "UNAL"
    )

## Load required library
library(sp)

?sp## Set desired transect subsection maximum length, in meters
section_length = 3000


### SECTION 2: CALCULATE STRIP-TRANSECT BINS FROM LINEAR DISTANCES AND ANGLES
## Calculate strip-transect bins, based on distances and angles
# Convert linear distance bins to a numeric field, using the maximum distance within each bin
DAT$Dist_Numeric = NA
for (i in 1:nrow(DAT)){
     if (DAT$Distance[i] == "D1") {DAT$Dist_Numeric[i] = 50}
     if (DAT$Distance[i] == "D2") {DAT$Dist_Numeric[i] = 100}
     if (DAT$Distance[i] == "D3") {DAT$Dist_Numeric[i] = 150}
     if (DAT$Distance[i] == "D4") {DAT$Dist_Numeric[i] = 200}
     if (DAT$Distance[i] == "D5") {DAT$Dist_Numeric[i] = 300}
}

# Calculate the distance abeam. Angle is converted from degrees to radians before sin function
DAT$Abeam = DAT$Dist_Numeric*sin(DAT$Angle*pi/180)

# Convert numeric distance abeam to bins (0-100 = 1, 100-200 = 2, 200-300 = 3, >300 = 9, also 9 if Abeam > SurveyDistance)
for (i in 1:nrow(DAT)){
     if (is.na(DAT$Distance[i]) == "TRUE") {DAT$Bin[i] = DAT$Bin[i]} else {
            if (DAT$Distance[i] == "D6") {DAT$Bin[i] = 9}} 
     if (is.na(DAT$Abeam[i]) == "TRUE") {DAT$Bin[i] = DAT$Bin[i]} else {
            if (DAT$Abeam[i] <= 300) {DAT$Bin[i] = 3}
            if (DAT$Abeam[i] <= 200) {DAT$Bin[i] = 2}
            if (DAT$Abeam[i] <= 100) {DAT$Bin[i] = 1}
            if (DAT$Abeam[i] > DAT$Survey_Distance[i]) {DAT$Bin[i] = 9}}
}

# Remove temporary columns
drops = c("Dist_Numeric",  "Abeam")
DAT = DAT[,!(names(DAT)%in%drops)]


### SECTION 3: SUBDIVIDE DATA INTO CONTIGUOUS 3-KM TRANSECT SUBSECTIONS
## Reformat date/time
DAT$DATE_TIME = paste(DAT$YYYY, "-", DAT$MO, "-", DAT$DD, " ", DAT$hh, ":", DAT$mm, ":", DAT$ss, sep="")
DAT$DATE_TIME = as.POSIXct(strptime(DAT$DATE_TIME, format="%Y-%m-%d %H:%M:%S"), tz="")

## Split survey data into contiguous survey sections (sections of transect without a pause)
# First, extract the start/end/pause/resume signals from the comments
DAT$Signal = NA
for (i in 1:nrow(DAT)){
    if (DAT$Comment1[i] == "START TRAN") {DAT$Signal[i] = "START TRAN"} else {DAT$Signal[i] = ""}
    if (DAT$Comment1[i] == "END TRAN") {DAT$Signal[i] = "END TRAN"} else {DAT$Signal[i] = DAT$Signal[i]}
    if (DAT$Comment1[i] == "PAUSE TRAN") {DAT$Signal[i] = "PAUSE TRAN"} else {DAT$Signal[i] = DAT$Signal[i]}
    if (DAT$Comment1[i] == "RESUME TRAN") {DAT$Signal[i] = "RESUME TRAN"} else {DAT$Signal[i] = DAT$Signal[i]}  
}

# Give transect sections after each pause a new temporary transect name in a temporary new column, "Transect_Split"
DAT$Transect_Split = paste(as.character(DAT$Transect), "_", sep="")
for (i in 1:nrow(DAT)){
    DAT$Transect_Split[i] = paste(DAT$Transect_Split[i], "I", sep="")
}
for (i in 1:nrow(DAT)){
    if (DAT$Signal[i] == "START TRAN") {DAT$Transect_Split[i] = DAT$Transect_Split[i]}
    if (DAT$Signal[i] == "RESUME TRAN") {DAT$Transect_Split[i] = paste(as.character(DAT$Transect_Split[i-1]), "I", sep="")}
    if (DAT$Signal[i] == "END TRAN") {DAT$Transect_Split[i] = DAT$Transect_Split[i-1]}
    if (DAT$Signal[i] == "PAUSE TRAN") {DAT$Transect_Split[i] = DAT$Transect_Split[i-1]}
    if (DAT$Signal[i] == "") {DAT$Transect_Split[i] = DAT$Transect_Split[i-1]}
}
DAT$Transect_Split = as.factor(DAT$Transect_Split)

# Separate off-effort data from on-effort data
OFF = DAT[which(DAT$OnOffSurvy == "NO"),]
DAT = DAT[which(DAT$OnOffSurvy == "YES"),]

# Split the data frame into separate elements in a list, based on the new "Transect_Split" column
DATLIST = split(DAT, DAT$Transect_Split)

## For each observation, calculate along-transect distance from start of continuous transect section in meters
# Distance calculations use great circle distance along WGS84 elipsoid
for (i in 1:length(DATLIST)){
    DATLIST[[i]]$PairwiseDist = 0
    DATLIST[[i]]$AlongTranDist = 0
    for (j in 2:nrow(DATLIST[[i]])){
        xy1 = cbind(DATLIST[[i]][j-1,3] , DATLIST[[i]][j-1,2])
        xy2 = cbind(DATLIST[[i]][j,3] , DATLIST[[i]][j,2])   
        xy = rbind (xy1,xy2)
        distmat = spDists(xy, longlat=T)
        DATLIST[[i]]$PairwiseDist[j] = distmat[1,2]*1000
        DATLIST[[i]]$AlongTranDist[j] = sum(DATLIST[[i]]$PairwiseDist, na.rm = TRUE)
    }
}

## Create temporary 3-km transect subsection name field, "Section", and assign each observation to its subsection
for (i in 1:length(DATLIST)){
    DATLIST[[i]]$Section = NA
    totdist = max(DATLIST[[i]]$AlongTranDist)
    numsections = round(totdist/section_length, 1)
    SXN = DATLIST[[i]]$AlongTranDist/section_length
    SXN = floor(SXN+1)
    for (j in 1:length(SXN)){
        DATLIST[[i]]$Section[j] = SXN[j]
    }
}

## Convert back from list to data frame
DAT2 = do.call(rbind,DATLIST)

## Rename the 3-km transect subsections, in order within transects. 
# The renamed 3-km subsections are named in the column "Transect_Segments".
DAT2$Transect = factor(DAT2$Transect)
DAT2$Transect_Section<-paste(as.character(DAT2$Transect_Split), as.character(DAT2$Section), sep="_")
DAT2$Transect_Section = factor(DAT2$Transect_Section)
NAME_LIST = split(DAT2, DAT2$Transect)
for (i in 1:length(NAME_LIST)){
    NAME_LIST[[i]]$Transect_Section = factor(NAME_LIST[[i]]$Transect_Section)
    NAME_LEVELS = unique(NAME_LIST[[i]]$Transect_Section)
    NAME_NUMBERS = seq(1, length(NAME_LEVELS), 1)
    NEW_NAMES = data.frame(matrix(NA, nrow=length(NAME_LEVELS), ncol=1))
    colnames(NEW_NAMES) = c("NEW_NAMES")
        for (j in 1:nrow(NEW_NAMES)){
        NEW_NAMES[j,1] = paste(as.character(NAME_LIST[[i]]$Transect[1]), "_", NAME_NUMBERS[j], sep="")
        }
    NEW_NAMES$NEW_NAMES = as.factor(NEW_NAMES$NEW_NAMES)
    NAMES = data.frame(NAME_LEVELS, NEW_NAMES$NEW_NAMES)
    colnames(NAMES) = c("Transect_Section", "Transect_Segment")
    NAME_LIST[[i]] = merge(NAME_LIST[[i]], NAMES, by="Transect_Section", all.x=TRUE)
}
DAT3 = do.call(rbind, NAME_LIST)
DAT3 = DAT3[order(DAT3$KEY),]


### SECTION 4: CALCULATE DENSITIES SUMMARY STATISTICS
## Calculate summary information for each transect segment
# Split data into list by segment
DAT3_LIST = split(DAT3, DAT3$Transect_Segment)

# Create data frame with transect segment summary information
SUMMARY = data.frame(matrix(NA, nrow=length(DAT3_LIST), ncol=12))
colnames(SUMMARY) = c("Transect_Segment", "year", "month", "day", "juliand", "mLat", "mLong", 
                  "tLength", "TransectWidth", "tArea", "startTime", "endTime")

# calculate subsection summary information
for (i in 1:length(DAT3_LIST)){
    SUMMARY[i,1] = as.character(DAT3_LIST[[i]]$Transect_Segment[1])
    SUMMARY[i,2] = DAT3_LIST[[i]]$YYYY[1]
    SUMMARY[i,3] = DAT3_LIST[[i]]$MO[1]
    SUMMARY[i,4] = DAT3_LIST[[i]]$DD[1]
    SUMMARY[i,5] = as.numeric(strftime(DAT3_LIST[[i]]$DATE_TIME[1], format = "%j"))
    GPS = DAT3_LIST[[i]][which(DAT3_LIST[[i]]$Type=="GPS"),]
    USER = DAT3_LIST[[i]][which(DAT3_LIST[[i]]$Type=="USER"),]
    # to avoid bias, mean lat/long calculated from automatic data only; calculates from user entries only if there are no auto data
    if (nrow(GPS) > 0){SUMMARY[i,6] = mean(GPS$Latitude); SUMMARY[i,7] = mean(GPS$Longitude)} else {
        SUMMARY[i,6] = mean(USER$Latitude); SUMMARY[i,7] = mean(USER$Longitude)} 
    n<-nrow(DAT3_LIST[[i]])    
    SUMMARY[i,8] = DAT3_LIST[[i]]$AlongTranDist[n] - DAT3_LIST[[i]]$AlongTranDist[1]
    # If TransectWidth value is other than 100, 200, or 300, it indicates Survey_Distance changed during tran (error check).
    SUMMARY[i,9] = mean(DAT3_LIST[[i]]$Survey_Distance)
    SUMMARY[i,10] = SUMMARY[i,8] * SUMMARY[i,9]
    SUMMARY[i,11] = paste(DAT3_LIST[[i]]$hh[1], ":", DAT3_LIST[[i]]$mm[1], ":", DAT3_LIST[[i]]$ss[1], sep="") 
    SUMMARY[i,12] = paste(DAT3_LIST[[i]]$hh[n], ":", DAT3_LIST[[i]]$mm[n], ":", DAT3_LIST[[i]]$ss[n], sep="")   
}

## Calculate density of each taxon within each subsection
# Create data frame with density for each subsection
DEN = data.frame(matrix(0, nrow=nrow(SUMMARY), ncol=length(TAXA)))
colnames(DEN) = TAXA

# Extract observations of the taxa in specificed in "TAXA"
STG = DAT3[which(DAT3$Spp %in% TAXA),]

# remove off-transect sightings (remove off-effort, bin-9, and behavior "FLYING" or "DEAD")
STG = STG[which(STG$OnOffSurvy=="YES"),]
STG = STG[which(STG$Bin != "9"),]
STG = STG[which(STG$Behavior != "FLYING"),]
STG = STG[which(STG$Behavior != "DEAD"),]

# Calculate density for each taxon
for (i in 1:nrow(DEN)){
    for (j in 1:ncol(DEN)){
        area = SUMMARY$tArea[i]/1000000
        sppdat = STG[which(STG$Spp==TAXA[j]),]
        sppdat = sppdat[which(sppdat$Transect_Segment==SUMMARY$Transect_Segment[i]),]
        if (area > 0) {DEN[i,j] = sum(sppdat$Number)/area} else {DEN[i,j] = 0}
}} 

## Combine subsection summary and density outputs, and resort into chronological order
OUT = cbind(SUMMARY, DEN)
OUT = OUT[order(OUT$juliand, as.POSIXct(strptime(OUT$startTime, format="%H:%M:%S"), tz="")),]


### SECTION 5: REFORMAT AND OUTPUT PROCESSED FILES
## Do some reformatting of the dlog file prior to output
# Put transect segment information into the "Comment3" field of the dlog file
DAT3$Comment3 = DAT3$Transect_Segment

# Add the off-effort data back in to the dlog file. 
# Delete temporary columns from DAT3 that were created since off-effort data was separated
drops = c("PairwiseDist",  "AlongTranDist", "Section", "Transect_Section", "Transect_Segment")
DAT3 = DAT3[,!(names(DAT3)%in%drops)]

# Cecombine the files
DAT4 = rbind(DAT3, OFF)
DAT4 = DAT4[order(DAT4$KEY),]

# Assign subsection name to off-effort data (corresponding to when went off-effort)
for (i in 1:nrow(DAT4)){
    if (DAT4$Comment3[i]=="") {DAT4$Comment3[i] = DAT4$Comment3[i-1]} else { DAT4$Comment3[i] = DAT4$Comment3[i]}
}

# Delete remaining temprary columns
drops = c("DATE_TIME", "Signal", "Transect_Split")
DAT4 = DAT4[,!(names(DAT4)%in%drops)]

# Convert NAs in several fields to blanks, as they were coded in the orginal dlog file
for (i in 1:nrow(DAT4)){
    if (is.na(DAT4$Number[i])=="TRUE") {DAT4$Number[i] = ""} else {DAT4$Number[i] = DAT4$Number[i]}
    if (is.na(DAT4$Angle[i])=="TRUE") {DAT4$Angle[i] = ""} else {DAT4$Angle[i] = DAT4$Angle[i]}
    if (is.na(DAT4$Bin[i])=="TRUE") {DAT4$Bin[i] = ""} else {DAT4$Bin[i] = DAT4$Bin[i]}    
}

## Write the processed files
# Write processed dlog file
surv = as.character(DAT$Survey[1])
filename1 = paste(surv, as.character("SeabirdData_Dlog_Processed.csv"), sep="_")
write.table(DAT4, filename1, sep=",", row.names=FALSE)

# Write subsection summary and density file
filename2 = paste(surv, as.character("SeabirdData_Densities.csv"), sep="_")
write.table(OUT, filename2, sep=",", row.names=FALSE)